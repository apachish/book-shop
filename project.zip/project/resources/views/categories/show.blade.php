@extends('layouts.main')
@section('content')
    <h3>
        {{$category->name}}
    </h3>
@endsection