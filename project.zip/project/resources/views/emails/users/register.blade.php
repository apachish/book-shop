@extends('emails.layouts.app')
@section('content')
    Welcome {{$user->name}}
    Thanks for subscribing to our site.
@endsection